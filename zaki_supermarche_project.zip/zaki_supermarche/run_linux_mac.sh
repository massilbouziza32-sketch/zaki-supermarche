#!/bin/sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
export SECRET_KEY="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
export ADMIN_EMAIL="admin@zaki.dz"
export ADMIN_PASSWORD="ChangeThisPassword123!"
python app.py
