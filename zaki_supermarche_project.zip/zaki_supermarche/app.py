import os, sys, uuid
from datetime import datetime, date
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "CHANGE-ME-BEFORE-PUBLISHING")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///zaki_supermarche.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = os.path.join(app.root_path, "static", "uploads")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
db = SQLAlchemy(app)

CATEGORIES = [
    "المنتجات الغذائية", "المشروبات الغازية", "الأجبان والحليب",
    "الأطفال والرضع", "توابل وعقارات", "مواد التنظيف"
]
ALLOWED = {"png", "jpg", "jpeg", "webp"}

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(180), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # admin, livreur, siz
    def set_password(self, value): self.password_hash = generate_password_hash(value)
    def check_password(self, value): return check_password_hash(self.password_hash, value)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False, default=0)
    unit = db.Column(db.String(30), default="قطعة")
    image = db.Column(db.String(255), default="")
    active = db.Column(db.Boolean, default=True)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(180), nullable=False)
    phone = db.Column(db.String(40), nullable=False)
    address = db.Column(db.String(500), nullable=False)
    payment_method = db.Column(db.String(30), nullable=False)
    receipt_image = db.Column(db.String(255), default="")
    status = db.Column(db.String(30), default="جديد")
    total = db.Column(db.Float, nullable=False, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False)
    product_name = db.Column(db.String(180), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(30), default="قطعة")
    unit_price = db.Column(db.Float, nullable=False)
    line_total = db.Column(db.Float, nullable=False)

class Setting(db.Model):
    key = db.Column(db.String(80), primary_key=True)
    value = db.Column(db.String(500), default="")

def setting(key, default=""):
    item = db.session.get(Setting, key)
    return item.value if item else default

def set_setting(key, value):
    item = db.session.get(Setting, key)
    if not item:
        item = Setting(key=key)
        db.session.add(item)
    item.value = value

@app.context_processor
def globals_for_templates():
    return {"shop_name": setting("shop_name", "Zaki Supermarché"),
            "shop_logo": setting("shop_logo", ""), "rip": setting("rip", ""),
            "categories": CATEGORIES, "current_user": get_user()}

def get_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

def roles_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            user = get_user()
            if not user:
                flash("يرجى تسجيل الدخول أولا", "error")
                return redirect(url_for("login"))
            if user.role not in roles: abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return deco

def save_image(file):
    if not file or not file.filename: return ""
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED: raise ValueError("صيغة الصورة غير مدعومة. استخدم PNG أو JPG أو WEBP.")
    name = secure_filename(str(uuid.uuid4()) + "." + ext)
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], name))
    return name

@app.route("/")
def home():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    query = Product.query.filter_by(active=True)
    if q: query = query.filter(Product.name.ilike(f"%{q}%"))
    if category in CATEGORIES: query = query.filter_by(category=category)
    products = query.order_by(Product.name).all()
    return render_template("home.html", products=products, q=q, selected=category)

@app.post("/cart/add/<int:product_id>")
def add_cart(product_id):
    product = db.session.get(Product, product_id)
    if not product or not product.active: abort(404)
    try:
        qty = float(request.form.get("quantity", "1"))
        if qty <= 0 or qty > 10000: raise ValueError()
    except ValueError:
        flash("الكمية غير صحيحة", "error")
        return redirect(url_for("home"))
    cart = session.get("cart", {})
    cart[str(product_id)] = float(cart.get(str(product_id), 0)) + qty
    session["cart"] = cart
    flash("تمت إضافة المنتج إلى السلة")
    return redirect(request.referrer or url_for("home"))

@app.route("/cart")
def cart():
    lines, total = [], 0
    for pid, qty in session.get("cart", {}).items():
        p = db.session.get(Product, int(pid))
        if p and p.active:
            line = p.price * float(qty); total += line
            lines.append({"product": p, "qty": qty, "line": line})
    return render_template("cart.html", lines=lines, total=total)

@app.post("/checkout")
def checkout():
    cart_data = session.get("cart", {})
    if not cart_data:
        flash("السلة فارغة", "error"); return redirect(url_for("home"))
    name, phone, address = (request.form.get(k, "").strip() for k in ("customer_name","phone","address"))
    method = request.form.get("payment_method", "")
    if not name or not phone or not address or method not in ("baridimob", "cod"):
        flash("يرجى ملء جميع المعلومات واختيار طريقة الدفع", "error"); return redirect(url_for("cart"))
    proof = ""
    if method == "baridimob":
        try: proof = save_image(request.files.get("receipt"))
        except ValueError as e:
            flash(str(e), "error"); return redirect(url_for("cart"))
        if not proof:
            flash("أرفق صورة وصل الدفع لبريدي موب", "error"); return redirect(url_for("cart"))
    order = Order(customer_name=name, phone=phone, address=address,
                  payment_method=method, receipt_image=proof)
    total = 0
    db.session.add(order); db.session.flush()
    for pid, qty in cart_data.items():
        p = db.session.get(Product, int(pid))
        if not p or not p.active: continue
        qty = float(qty); line = p.price * qty; total += line
        db.session.add(OrderItem(order_id=order.id, product_name=p.name,
                    quantity=qty, unit=p.unit, unit_price=p.price, line_total=line))
    order.total = total
    db.session.commit()
    session["cart"] = {}
    return render_template("thanks.html", order=order)

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form.get("email","").strip().lower()).first()
        if user and user.check_password(request.form.get("password","")):
            session.clear(); session["user_id"] = user.id
            return redirect(url_for({"admin":"admin","livreur":"livreur","siz":"siz"}[user.role]))
        flash("البريد الإلكتروني أو كلمة المرور غير صحيحة", "error")
    return render_template("login.html")

@app.get("/logout")
def logout():
    session.clear(); return redirect(url_for("home"))

@app.route("/admin", methods=["GET","POST"])
@roles_required("admin")
def admin():
    if request.method == "POST":
        set_setting("shop_name", request.form.get("shop_name","Zaki Supermarché").strip())
        set_setting("rip", request.form.get("rip","").strip())
        try:
            logo = save_image(request.files.get("logo"))
            if logo: set_setting("shop_logo", logo)
        except ValueError as e: flash(str(e), "error")
        db.session.commit(); flash("تم حفظ إعدادات المتجر")
        return redirect(url_for("admin"))
    today = date.today()
    orders_today = Order.query.filter(db.func.date(Order.created_at) == today.isoformat()).all()
    daily = db.session.query(db.func.date(Order.created_at), db.func.count(Order.id),
             db.func.coalesce(db.func.sum(Order.total),0)).group_by(
             db.func.date(Order.created_at)).order_by(db.func.date(Order.created_at).desc()).limit(90).all()
    return render_template("admin.html", orders_today=orders_today, daily=daily,
        count_today=len(orders_today), total_today=sum(o.total for o in orders_today))

@app.route("/admin/products", methods=["GET","POST"])
@roles_required("admin")
def admin_products():
    if request.method == "POST":
        try:
            image = save_image(request.files.get("image"))
            p = Product(name=request.form.get("name","").strip(),
                category=request.form.get("category",""), price=float(request.form.get("price",0)),
                unit=request.form.get("unit","قطعة").strip() or "قطعة", image=image)
            if not p.name or p.category not in CATEGORIES or p.price < 0: raise ValueError()
            db.session.add(p); db.session.commit(); flash("تمت إضافة المنتج")
        except (ValueError, TypeError):
            db.session.rollback(); flash("تحقق من الاسم والقسم والسعر والصورة", "error")
        return redirect(url_for("admin_products"))
    return render_template("products_admin.html", products=Product.query.order_by(Product.category,Product.name).all())

@app.post("/admin/products/<int:pid>/edit")
@roles_required("admin","siz")
def edit_product(pid):
    p = db.get_or_404(Product, pid)
    try:
        p.name = request.form.get("name", p.name).strip()
        p.price = float(request.form.get("price", p.price))
        img = save_image(request.files.get("image"))
        if img: p.image = img
        if p.price < 0 or not p.name: raise ValueError()
        db.session.commit(); flash("تم تعديل المنتج")
    except (ValueError, TypeError):
        db.session.rollback(); flash("بيانات غير صحيحة", "error")
    return redirect(request.referrer or url_for("siz"))

@app.post("/admin/products/<int:pid>/delete")
@roles_required("admin")
def delete_product(pid):
    p = db.get_or_404(Product,pid); p.active = False; db.session.commit()
    flash("تم إخفاء المنتج من المتجر")
    return redirect(url_for("admin_products"))

@app.route("/livreur")
@roles_required("livreur","admin")
def livreur():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template("livreur.html", orders=orders)

@app.post("/livreur/<int:oid>/status")
@roles_required("livreur","admin")
def update_order(oid):
    order = db.get_or_404(Order, oid)
    status = request.form.get("status")
    if status in ("جديد","قيد المعالجة","خرج للتوصيل","تم التسليم","ملغى"):
        order.status = status; db.session.commit(); flash("تم تحديث حالة الطلبية")
    return redirect(url_for("livreur"))

@app.get("/receipt/<int:oid>")
@roles_required("livreur","admin")
def receipt(oid):
    order = db.get_or_404(Order, oid)
    items = OrderItem.query.filter_by(order_id=oid).all()
    return render_template("receipt.html", order=order, items=items)

@app.route("/siz", methods=["GET","POST"])
@roles_required("siz","admin")
def siz():
    if request.method == "POST":
        try:
            image = save_image(request.files.get("image"))
            p = Product(name=request.form.get("name","").strip(),
                category=request.form.get("category",""),
                price=float(request.form.get("price",0)),
                unit=request.form.get("unit","قطعة").strip() or "قطعة",
                image=image)
            if not p.name or p.category not in CATEGORIES or p.price < 0:
                raise ValueError()
            db.session.add(p); db.session.commit(); flash("تمت إضافة السلعة إلى الرف")
        except (ValueError, TypeError):
            db.session.rollback(); flash("تحقق من الاسم والقسم والسعر", "error")
        return redirect(url_for("siz"))
    return render_template("siz.html", products=Product.query.order_by(Product.category,Product.name).all())

@app.cli.command("create-user")
def create_user():
    """إنشاء مستخدم: flask create-user ثم أدخل البيانات في التطبيق البرمجي؟ استخدم متغيرات البيئة أدناه."""
    email=os.getenv("NEW_USER_EMAIL","").strip().lower()
    password=os.getenv("NEW_USER_PASSWORD","")
    role=os.getenv("NEW_USER_ROLE","livreur")
    if not email or not password or role not in ("admin","livreur","siz"):
        print("حدد NEW_USER_EMAIL و NEW_USER_PASSWORD و NEW_USER_ROLE (admin/livreur/siz)")
        return
    with app.app_context():
        if User.query.filter_by(email=email).first():
            print("هذا البريد مسجل مسبقا"); return
        u=User(email=email,role=role); u.set_password(password)
        db.session.add(u); db.session.commit(); print("تم إنشاء المستخدم")

def initialize():
    with app.app_context():
        db.create_all()
        for c in CATEGORIES:
            # الأقسام محفوظة في الكود ولا تحتاج إلى جدول مستقل
            pass
        email=os.getenv("ADMIN_EMAIL","admin@zaki.dz").strip().lower()
        password=os.getenv("ADMIN_PASSWORD","")
        if password and not User.query.filter_by(email=email).first():
            u=User(email=email,role="admin"); u.set_password(password); db.session.add(u); db.session.commit()

initialize()
if __name__ == "__main__":
    if len(sys.argv)>1 and sys.argv[1]=="create-user":
        with app.app_context():
            email=input("Email: ").strip().lower()
            password=input("Password: ")
            role=input("Role (admin/livreur/siz): ").strip()
            if role not in ("admin","livreur","siz"): raise SystemExit("دور غير صالح")
            if User.query.filter_by(email=email).first(): raise SystemExit("البريد موجود")
            u=User(email=email,role=role); u.set_password(password); db.session.add(u); db.session.commit()
            print("User created")
    else:
        app.run(host="127.0.0.1", port=5000, debug=True)
